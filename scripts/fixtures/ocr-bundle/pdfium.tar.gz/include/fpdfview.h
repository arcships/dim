fixture pdfium header
